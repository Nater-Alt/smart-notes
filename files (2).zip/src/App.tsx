import React from 'react';
import './styles/index.css';
import Sidebar from './components/Sidebar/Sidebar';
import Toolbar from './components/Toolbar/Toolbar';
import DrawingCanvas from './components/Canvas/DrawingCanvas';
import AIPanel from './components/AIPanel/AIPanel';
import TextSelectionHandler from './components/TextSelection/TextSelectionHandler';
import { NotesProvider } from './contexts/NotesContext';
import { ToolProvider } from './contexts/ToolContext';

const App: React.FC = () => {
  return (
    <NotesProvider>
      <ToolProvider>
        <div className="app-container">
          <Sidebar />
          <div className="main-content">
            <Toolbar />
            <DrawingCanvas />
            <AIPanel />
            <TextSelectionHandler />
          </div>
        </div>
      </ToolProvider>
    </NotesProvider>
  );
};

export default App;
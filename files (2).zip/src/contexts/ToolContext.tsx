import React, { createContext, useContext, useState } from 'react';
import { Tool, AIPanelState } from '../types';

interface ToolContextType {
  currentTool: Tool;
  setCurrentTool: (tool: Tool) => void;
  penColor: string;
  setPenColor: (color: string) => void;
  penSize: number;
  setPenSize: (size: number) => void;
  aiPanel: AIPanelState;
  setAIPanel: React.Dispatch<React.SetStateAction<AIPanelState>>;
}

const ToolContext = createContext<ToolContextType | undefined>(undefined);

export const ToolProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTool, setCurrentTool] = useState<Tool>('pen');
  const [penColor, setPenColor] = useState('#000000');
  const [penSize, setPenSize] = useState(2);
  const [aiPanel, setAIPanel] = useState<AIPanelState>({
    isVisible: false,
    selectedText: '',
    explanation: '',
    isLoading: false
  });

  return (
    <ToolContext.Provider value={{ 
      currentTool, 
      setCurrentTool, 
      penColor, 
      setPenColor, 
      penSize, 
      setPenSize,
      aiPanel,
      setAIPanel
    }}>
      {children}
    </ToolContext.Provider>
  );
};

export const useTools = () => {
  const context = useContext(ToolContext);
  if (context === undefined) {
    throw new Error('useTools must be used within a ToolProvider');
  }
  return context;
};
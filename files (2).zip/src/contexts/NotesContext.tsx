import React, { createContext, useContext, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Note } from '../types';

interface NotesContextType {
  notes: Note[];
  currentNote: Note | null;
  createNote: (type: 'blank' | 'pdf' | 'image', content?: string) => void;
  selectNote: (id: string) => void;
  updateNote: (id: string, updates: Partial<Note>) => void;
  deleteNote: (id: string) => void;
}

const NotesContext = createContext<NotesContextType | undefined>(undefined);

export const NotesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [currentNote, setCurrentNote] = useState<Note | null>(null);

  const createNote = (type: 'blank' | 'pdf' | 'image', content: string = '') => {
    const now = new Date();
    const newNote: Note = {
      id: uuidv4(),
      title: `Untitled Note ${notes.length + 1}`,
      content,
      type,
      createdAt: now,
      updatedAt: now,
    };

    setNotes([...notes, newNote]);
    setCurrentNote(newNote);
  };

  const selectNote = (id: string) => {
    const note = notes.find(note => note.id === id) || null;
    setCurrentNote(note);
  };

  const updateNote = (id: string, updates: Partial<Note>) => {
    setNotes(notes.map(note => 
      note.id === id ? { ...note, ...updates, updatedAt: new Date() } : note
    ));

    if (currentNote?.id === id) {
      setCurrentNote({ ...currentNote, ...updates, updatedAt: new Date() });
    }
  };

  const deleteNote = (id: string) => {
    setNotes(notes.filter(note => note.id !== id));
    if (currentNote?.id === id) {
      setCurrentNote(null);
    }
  };

  return (
    <NotesContext.Provider value={{ 
      notes, 
      currentNote, 
      createNote, 
      selectNote, 
      updateNote, 
      deleteNote 
    }}>
      {children}
    </NotesContext.Provider>
  );
};

export const useNotes = () => {
  const context = useContext(NotesContext);
  if (context === undefined) {
    throw new Error('useNotes must be used within a NotesProvider');
  }
  return context;
};
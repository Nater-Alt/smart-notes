import React from 'react';
import { useNotes } from '../../contexts/NotesContext';
import { BsFileEarmark, BsPlus, BsUpload } from 'react-icons/bs';

const Sidebar: React.FC = () => {
  const { notes, createNote, selectNote, currentNote } = useNotes();
  
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      
      if (file.type === 'application/pdf') {
        createNote('pdf', content);
      } else if (file.type.startsWith('image/')) {
        createNote('image', content);
      }
    };
    
    if (file.type === 'application/pdf' || file.type.startsWith('image/')) {
      reader.readAsDataURL(file);
    }
    
    // Reset input
    event.target.value = '';
  };

  return (
    <div className="sidebar flex flex-col items-center py-4">
      <div className="mb-6">
        <span className="font-bold text-lg">SN</span>
      </div>
      
      <button 
        className="tool-button mb-2"
        onClick={() => createNote('blank')}
        title="New Note"
      >
        <BsPlus size={24} />
      </button>
      
      <label className="tool-button mb-4 cursor-pointer" title="Upload File">
        <BsUpload size={20} />
        <input 
          type="file"
          accept="application/pdf,image/*"
          onChange={handleFileUpload}
          className="hidden"
        />
      </label>
      
      <div className="flex flex-col items-center mt-4">
        {notes.map((note) => (
          <button 
            key={note.id}
            className={`tool-button ${currentNote?.id === note.id ? 'tool-active' : ''}`}
            onClick={() => selectNote(note.id)}
          >
            <BsFileEarmark size={20} />
          </button>
        ))}
      </div>
    </div>
  );
};

export default Sidebar;
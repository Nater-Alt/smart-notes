import React from 'react';
import { useTools } from '../../contexts/ToolContext';
import { analyzeText } from '../../services/AIService';
import { BsX, BsArrowReturnRight } from 'react-icons/bs';

const AIPanel: React.FC = () => {
  const { aiPanel, setAIPanel } = useTools();
  
  const handleAnalyze = async () => {
    if (!aiPanel.selectedText) return;
    
    setAIPanel({
      ...aiPanel,
      isLoading: true,
      explanation: ''
    });
    
    try {
      const explanation = await analyzeText(aiPanel.selectedText);
      setAIPanel({
        ...aiPanel,
        explanation,
        isLoading: false
      });
    } catch (error) {
      console.error('Error analyzing text:', error);
      setAIPanel({
        ...aiPanel,
        explanation: 'Failed to analyze text. Please try again.',
        isLoading: false
      });
    }
  };
  
  const closePanel = () => {
    setAIPanel({
      isVisible: false,
      selectedText: '',
      explanation: '',
      isLoading: false
    });
  };
  
  if (!aiPanel.isVisible) return null;
  
  return (
    <div className="ai-panel">
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-lg font-semibold">AI Explanation</h3>
        <button onClick={closePanel} className="p-1">
          <BsX size={24} />
        </button>
      </div>
      
      <div className="mb-3">
        <p className="text-sm text-gray-600 mb-1">Selected Text:</p>
        <div className="p-2 bg-gray-50 rounded-md text-sm">
          {aiPanel.selectedText || "No text selected"}
        </div>
      </div>
      
      {!aiPanel.explanation && (
        <button 
          onClick={handleAnalyze}
          disabled={!aiPanel.selectedText || aiPanel.isLoading}
          className="bg-blue-500 text-white px-4 py-2 rounded-md flex items-center justify-center w-full disabled:opacity-50"
        >
          {aiPanel.isLoading ? 'Analyzing...' : 'Get Explanation'}
        </button>
      )}
      
      {aiPanel.explanation && (
        <div className="mt-3">
          <p className="
import React from 'react';
import { ChromePicker } from 'react-color';
import { useTools } from '../../contexts/ToolContext';
import { BsCursor, BsPen, BsEraser, BsType, BsSquare } from 'react-icons/bs';
import { FaHighlighter } from 'react-icons/fa';

const Toolbar: React.FC = () => {
  const { 
    currentTool, 
    setCurrentTool, 
    penColor, 
    setPenColor, 
    penSize, 
    setPenSize 
  } = useTools();
  
  const [showColorPicker, setShowColorPicker] = React.useState(false);

  return (
    <div className="toolbar flex justify-between">
      <div className="tool-buttons flex">
        <button 
          className={`tool-button ${currentTool === 'select' ? 'tool-active' : ''}`}
          onClick={() => setCurrentTool('select')}
        >
          <BsCursor size={20} />
        </button>
        <button 
          className={`tool-button ${currentTool === 'pen' ? 'tool-active' : ''}`}
          onClick={() => setCurrentTool('pen')}
        >
          <BsPen size={20} />
        </button>
        <button 
          className={`tool-button ${currentTool === 'highlighter' ? 'tool-active' : ''}`}
          onClick={() => setCurrentTool('highlighter')}
        >
          <FaHighlighter size={20} />
        </button>
        <button 
          className={`tool-button ${currentTool === 'eraser' ? 'tool-active' : ''}`}
          onClick={() => setCurrentTool('eraser')}
        >
          <BsEraser size={20} />
        </button>
        <button 
          className={`tool-button ${currentTool === 'text' ? 'tool-active' : ''}`}
          onClick={() => setCurrentTool('text')}
        >
          <BsType size={20} />
        </button>
        <button 
          className={`tool-button ${currentTool === 'shape' ? 'tool-active' : ''}`}
          onClick={() => setCurrentTool('shape')}
        >
          <BsSquare size={20} />
        </button>
      </div>
      
      <div className="flex items-center">
        <div className="relative mr-4">
          <button 
            className="w-8 h-8 rounded-md border border-gray-300"
            style={{ backgroundColor: penColor }}
            onClick={() => setShowColorPicker(!showColorPicker)}
          />
          {showColorPicker && (
            <div className="absolute z-10 top-10 right-0">
              <div className="fixed inset-0" onClick={() => setShowColorPicker(false)} />
              <ChromePicker color={penColor} onChange={(color) => setPenColor(color.hex)} />
            </div>
          )}
        </div>
        
        <div className="flex items-center">
          <span className="mr-2">Size:</span>
          <input 
            type="range" 
            min="1" 
            max="20" 
            value={penSize}
            onChange={(e) => setPenSize(parseInt(e.target.value))}
            className="w-24"
          />
        </div>
      </div>
    </div>
  );
};

export default Toolbar;
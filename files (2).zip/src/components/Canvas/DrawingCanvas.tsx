import React, { useEffect, useRef } from 'react';
import { Canvas, IText, IEvent } from 'fabric';
import { useTools } from '../../contexts/ToolContext';
import { useNotes } from '../../contexts/NotesContext';

const DrawingCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fabricCanvasRef = useRef<Canvas | null>(null);
  const { currentTool, penColor, penSize } = useTools();
  const { currentNote, updateNote } = useNotes();

  // Initialize canvas
  useEffect(() => {
    if (canvasRef.current) {
      fabricCanvasRef.current = new Canvas(canvasRef.current, {
        width: window.innerWidth,
        height: window.innerHeight - 60,
        backgroundColor: '#ffffff'
      });

      const handleResize = () => {
        if (fabricCanvasRef.current) {
          fabricCanvasRef.current.setDimensions({
            width: window.innerWidth,
            height: window.innerHeight - 60
          });
        }
      };

      window.addEventListener('resize', handleResize);
      
      // Load canvas content if available
      if (currentNote?.canvasJson) {
        fabricCanvasRef.current.loadFromJSON(currentNote.canvasJson, () => {
          fabricCanvasRef.current?.renderAll();
        });
      }

      return () => {
        window.removeEventListener('resize', handleResize);
        fabricCanvasRef.current?.dispose();
      };
    }
  }, []);

  // Update canvas when current note changes
  useEffect(() => {
    if (fabricCanvasRef.current && currentNote?.canvasJson) {
      fabricCanvasRef.current.loadFromJSON(currentNote.canvasJson, () => {
        fabricCanvasRef.current?.renderAll();
      });
    } else if (fabricCanvasRef.current) {
      fabricCanvasRef.current.clear();
    }
  }, [currentNote]);

  // Save canvas state when it changes
  useEffect(() => {
    const saveCanvas = () => {
      if (fabricCanvasRef.current && currentNote) {
        const canvasJson = JSON.stringify(fabricCanvasRef.current.toJSON());
        updateNote(currentNote.id, { canvasJson });
      }
    };

    const canvas = fabricCanvasRef.current;
    if (canvas) {
      canvas.on('object:added', saveCanvas);
      canvas.on('object:modified', saveCanvas);
      canvas.on('object:removed', saveCanvas);

      return () => {
        canvas.off('object:added', saveCanvas);
        canvas.off('object:modified', saveCanvas);
        canvas.off('object:removed', saveCanvas);
      };
    }
  }, [currentNote, updateNote]);

  // Set up drawing modes based on current tool
  useEffect(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    canvas.isDrawingMode = currentTool === 'pen' || currentTool === 'highlighter';
    
    if (currentTool === 'pen') {
      canvas.freeDrawingBrush.color = penColor;
      canvas.freeDrawingBrush.width = penSize;
    } else if (currentTool === 'highlighter') {
      // For highlighter we use a semi-transparent yellow color
      canvas.freeDrawingBrush.color = 'rgba(255, 255, 0, 0.4)';
      canvas.freeDrawingBrush.width = penSize * 2;
    } else if (currentTool === 'eraser') {
      // Enable eraser functionality
      canvas.on('mouse:down', function(options: IEvent<MouseEvent>) {
        if (options.target) {
          canvas.remove(options.target);
        }
      });

      return () => {
        canvas.off('mouse:down');
      };
    } else if (currentTool === 'text') {
      canvas.on('mouse:down', function(options: IEvent<MouseEvent>) {
        const pointer = canvas.getPointer(options.e);
        const text = new IText('Type here...', {
          left: pointer.x,
          top: pointer.y,
          fontSize: 20,
          fill: penColor
        });
        canvas.add(text);
        canvas.setActiveObject(text);
      });

      return () => {
        canvas.off('mouse:down');
      };
    }
  }, [currentTool, penColor, penSize]);

  return (
    <div className="canvas-container">
      <canvas ref={canvasRef} />
    </div>
  );
};

export default DrawingCanvas;
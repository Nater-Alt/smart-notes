import React, { useEffect } from 'react';
import { useTools } from '../../contexts/ToolContext';

const TextSelectionHandler: React.FC = () => {
  const { setAIPanel } = useTools();

  useEffect(() => {
    const handleSelection = () => {
      const selection = window.getSelection();
      if (selection && !selection.isCollapsed) {
        const selectedText = selection.toString().trim();
        
        // Only show the AI panel for meaningful selections
        if (selectedText.length > 1) {
          setAIPanel({
            isVisible: true,
            selectedText,
            explanation: '',
            isLoading: false
          });
        }
      }
    };

    document.addEventListener('mouseup', handleSelection);
    return () => {
      document.removeEventListener('mouseup', handleSelection);
    };
  }, [setAIPanel]);

  return null;
};

export default TextSelectionHandler;
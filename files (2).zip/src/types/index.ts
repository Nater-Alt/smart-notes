export interface Note {
  id: string;
  title: string;
  content: string;
  type: 'blank' | 'pdf' | 'image';
  canvasJson?: string;
  createdAt: Date;
  updatedAt: Date;
}

export type Tool = 'select' | 'pen' | 'highlighter' | 'eraser' | 'text' | 'shape';

export type AIPanelState = {
  isVisible: boolean;
  selectedText: string;
  explanation: string;
  isLoading: boolean;
};